
#define MAX_PRICE 100000
#define MAX_INPUTS 100000

#include <iostream>
#include <vector>
#include <map>
#include <format>
#include <string>
#include <array>
#include <chrono>
#include <cmath>
// #include <thread>

using namespace std;

//
// literally using an array in cpp is problematic-
// passing it around as parameter turns it into a pointer,
// and we can no longer get the length;
//
// a vector is the "smart" equivalent,
// and can be inited just like an array:
//
//      int foo[] = { 1, 2 };
// vs
//      vector<int> foo = { 1, 2 };
//
// but includes built-in size operator

#undef USE_ARRAY
#if USE_ARRAY


#define DECLARE_INPUT(var,vals...) int var[] = vals

// macro works as long as array declared w/ init in same scope
#define ARRAY_LENGTH(a) (end(a)-begin(a))

// macro makes the invocation consistent w/ the challenge
#define Submission(a) _Submission(a, ARRAY_LENGTH(a))

// "real" method requires explicit indication of 
// # of days in prices array (i.e. length) as 2nd param
int _Submission(int prices[], int days);
#else

#define DECLARE_INPUT(var,vals...) vector<int> var = vals

int Submission( vector<int>& prices );

#endif

struct TestDefinition
{
    string name;
    int expectedResult;
    vector<int> inputs;
};

int TimedSubmission( TestDefinition& testDef );
string elapsedTime( double elapsedNanos );

extern bool DO_PROFILING;

// if the profiling flag is enabled, time the run, else just run it directly
#define INVOKE_SUBMISSION(testDef) \
    (DO_PROFILING ? TimedSubmission( testDef ) : Submission( testDef.inputs ))

int SimpleMain();

int TestMain();

int RunTest( TestDefinition testCase );

vector<TestDefinition> GetTestCases();
vector<TestDefinition> GetEdgeTestCases();
vector<TestDefinition> GetMaxTestCases();


