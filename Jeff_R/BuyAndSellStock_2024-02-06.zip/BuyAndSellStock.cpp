//
// J A K U B
//
// you can add your test cases to the JUDGE_TESTS var below;
// if filled in, these will automatically be used instead of the built-in test cases;
// by default, each JUDGE_TESTS result (maxProfit) is validated, 
// and each test is run ten times, with avg time for each reported after all tests are completed.
// 
// once you've declared your JUDGE_TESTS,
// you can use the following command-line flags 
// to further refine behavior:
// -r# repeat tests # times, report avg time per test
// -t- disable test mode (no validation)
// -p- disable profiling (timed execution)
// -j- ignore JUDGE_TEST, revert to built-in tests
//

#include "BuyAndSellStock.h"

vector<TestDefinition> JUDGE_TESTS = 
{
    /*
    {
        "test1Name",
        2, // expectedResult
        { 1, 2, 3 } // price per day inputs
    },
    {
        "test2Name",
        MAX_PRICE, // expectedResult
        { 0, MAX_PRICE } // price per day inputs
    }
    */
    // add as many tests as needed;
    // see the EXAMPLE_TEST_CASES definition below
};

// global flags controlled by cmdline args
int VERBOSE = 0;
bool DO_PROFILING = false; // time each run of the algorithm
bool RUN_TESTS = false; // enabled w/ -t, else only examples are run w/ no programmatic validation
bool EMIT_MAX_TEST_DATA = false;
int TEST_REPETITION = 1;
bool REPEAT_BY_TEST = true; // given { A, B, C } test suite + -r3, runs { A, A, A, B, B, B, C, C, C } else -R3 runs { A, B, C, A, B, C, A, B, C }
int main( int argc, char** argv )
{
    if( JUDGE_TESTS.size() > 0 )
    {
        // change some defaults in judge mode
        DO_PROFILING = true;
        RUN_TESTS = true;
        TEST_REPETITION = 10;
        // can be overridden with the command line
    }

    if( argc > 1 )
    {
        bool showSyntax = false;

        for( int argn = 1; argn < argc; argn++ )
        {
            char* currArg = argv[argn];
            if( currArg[0] == '-' )
            {
                switch( tolower(currArg[1]))
                {
                    case 'v':
                        switch( currArg[2] )
                        {
                            case '-':
                            case '0':
                                VERBOSE = 0;
                                break;
                            case '\0':
                            case '1':
                                VERBOSE = 1;
                                break;
                            case '2':
                                VERBOSE = 2;
                                break;
                            default:
                                showSyntax = true;
                                break;                        
                        }
                        break;
                    case 't':
                        RUN_TESTS = currArg[2] != '-';
                        break;
                    case 'p':
                        DO_PROFILING = currArg[2] != '-';
                        break;                        
                    case 'e':
                        EMIT_MAX_TEST_DATA = true;
                        GetMaxTestCases();
                        return 0;         
                    case 'j':
                        if( currArg[2] == '-')  
                            JUDGE_TESTS.clear();
                        break;
                    case 'r':
                        TEST_REPETITION = atoi(&currArg[2]);
                        REPEAT_BY_TEST = !(currArg[1] == 'R');
                        break;
                    default:
                        cout << "Unsupported argument: " << currArg << endl;
                    case 'h':
                    case '?':
                        showSyntax = true;
                        break;
                }
            }
            else
                showSyntax = true;

            if( showSyntax )
                break;
        }

        if( showSyntax )
        {
            cout 
                << endl
                << "Usage: "
                << "\t"
                << argv[0] // the name of the exe
                << " [-v[#|0|-]] [-t[-]] [-p[-]] [-r#] [-j-] [-e] [-?|-h]"
                << endl
                << "where"
                << "\t-v# sets verbose level:" << endl
                << "\t\t0: none/minimal" << endl
                << "\t\t1: summary" << endl
                << "\t\t2: working detail" << endl
                << "\t-v- is equivalent to -v0" << endl
                << "\t-v is equivalent to -v1" <<endl
                << endl
                << "\t-t run tests w/ result validation" << endl
                << "\t\tif not specified," << endl
                << "\t\tonly the examples are run w/ no validation" << endl
                << "\t\t(but algorithm results are written to console)" << endl
                << "\t-t- switch off test mode" << endl
                << endl
                << "\t-p enable profiling (time each invocation of the algorithm)" << endl
                << "\t-p- switch off profiling" << endl
                << endl
                << "\t-r#|-R# repeat tests # times" << endl
                << "\t\t-r# repeats N runs of each test back-to-back" << endl
                << "\t\t\tgiven {A, B} tests, -r2 would run {A, A, B, B}" << endl
                << "\t\t-R# repeats the test suite N times" << endl
                << "\t\t\tgiven {A, B} tests, -R2 would run {A, B, A, B}" << endl
                << "\t-r and -R are mutually exclusive- last one wins;" << endl
                << "\t# == 0 or 1 resets to running tests once;" << endl
                << "\tuse with -p to compute average time across multiple runs;" << endl
                << "\tNOTE this is the only case-sensitive parameter!" << endl
                << endl
                << "\t-j- ignore JUDGE_TESTS for this run" << endl
                << endl
                << "\t-e emit Max* test data to console" << endl
                << "\t\tif spec'd, only the test data is generated," << endl
                << "\t\tno tests are run, all other params ignored" << endl
                << endl
                << "\t-h or -? shows command-line syntax" << endl
                << endl
                ;
            
            return 0;
        }
    }

    int result = 0;

    if( RUN_TESTS )
    {
        result = TestMain();
    }
    else        
    {
        result = SimpleMain();
    }
    
    return result;
}

vector<TestDefinition> EXAMPLE_TEST_CASES = 
{
    {
        "Example1",
        6,
        {3,3,5,0,0,3,1,4}
    },
    {
        "Example2",
        4,
        {1,2,3,4,5}
    },
    {
        "Example3",
        0,
        {7,6,4,3,1}        
    }
}; // end of EXAMPLE_TEST_CASES

#define GetExampleTestCases() EXAMPLE_TEST_CASES

int SimpleMain()
{

    vector<TestDefinition> examples = JUDGE_TESTS.size() > 0 ? JUDGE_TESTS : GetExampleTestCases();

    for( int i = 0; i < examples.size(); i++ )
    {
        TestDefinition example = examples.at(i);

        cout << example.name << ": " << INVOKE_SUBMISSION(example) << endl;
    }

    return 0; // no errors
}

////////////////////////////////////////////////////////////////////
//
// The Solution algorithm
//

/// @brief struct to track a given transaction- buy+sell index+price, total profit
struct transaction {
    int buyIndex = -1; // zero-based day# of when we bought
    int buyPrice = 0; // price on the day we bought
    int sellIndex = -1; // zero-based day# of when we sold
    int sellPrice = 0; // price on the day we sold
    int profit = -1; // total profit
};

struct Profile {
    double elapsed;
    int runs;
};

map<string,Profile> perfTracker = {};

int TimedSubmission( TestDefinition& testDef )
{
    std::chrono::high_resolution_clock::time_point begin = std::chrono::high_resolution_clock::now();

    int maxProfit = Submission(testDef.inputs);

    // std::this_thread::sleep_for(std::chrono::milliseconds(15000));

    std::chrono::high_resolution_clock::time_point end = std::chrono::high_resolution_clock::now();

    // cout << "begin: " << format("%S", begin);

    double elapsed = std::chrono::duration_cast<std::chrono::nanoseconds> (end - begin).count();

    cout << " Elapsed Time: " << elapsedTime(elapsed) << " ";

    if( TEST_REPETITION > 1 )
    {
        map<string,Profile>::iterator it = perfTracker.find(testDef.name);
        if( it == perfTracker.end())
        {
            Profile profile = { elapsed, 1 };
            perfTracker.insert( make_pair( testDef.name, profile ));
        }
        else
        {
            it->second.elapsed += elapsed;
            it->second.runs++;
        }    
    }

    return maxProfit;
}

void dumpTransaction( const transaction& tx, const char* prefix );

#if USE_ARRAY
int _Submission( int prices[], int days )
#else
int Submission( vector<int>& prices )
#endif
{
    #if !USE_ARRAY
    int days = prices.size();
    #endif

    if( VERBOSE )
        cout << endl;

    int maxProfit = -1;

    // ARRAY_LENGTH(prices); // prices is really an int*, so we can't derive the length

    if( VERBOSE )
    {
        cout << "\t" << "Input: {";
        for( int i = 0; i < min(days, 10); i++ )
        {
            if( i )
                cout << ",";

            if( i < 5 || days <= 10 )                
            {
                cout << " " << prices.at(i);
            }
            else
            {
                if( i == 5 )
                    cout << " ... ";

                cout << " " << prices.at( days - 10 + i);
            }

        }

        cout << " }";

        cout << " " << "# of Days: " << days << endl;
    }

    // TODO compute maxProfit

    const transaction RESET;
    transaction first, second, current;
    
    int lastPrice = -1;

    //
    // NOTE we do an extra step to process the last dangling transaction
    //
    for( int day = 0; day <= days; day++ )
    {
        int price = day < days ? prices.at(day) : -1;

        if( price < lastPrice )
        {
            //
            // price dropped, sell for profit *if any*
            //

            if( VERBOSE == 2 )
            if( day < days )
                cout 
                    << "\t\tPrice dropped @"
                    << (day+1)
                    << " was "
                    << "$" << lastPrice
                    << " now "
                    << "$" << price
                    << " checking for profit..."
                    << endl
                    ;
            else
                cout
                    << "\t\tProcessing dangling *candidate* transaction..."
                    << endl
                    ;

            current.profit = current.sellPrice - current.buyPrice;

            if( current.profit > 0 )
            {
                //
                // we have a profitable transaction
                //
                if( first.profit < 0 )
                {
                    first = current;

                    if( VERBOSE == 2 )
                        dumpTransaction( first, "\t\tFound 1st *candidate* transaction: " );
                }
                else if( second.profit < 0 )
                {
                    second = current;

                    if( VERBOSE == 2 )
                        dumpTransaction( second, "\t\tFound 2nd *candidate* transaction: " );
                }
                else
                {
                    if( current.profit > first.profit || current.profit > second.profit )
                    {
                        if( VERBOSE == 2 )
                            cout 
                                << "\t\tFound more profitable transaction ("
                                << "new==$"
                                << current.profit
                                << " vs "
                                << " 1st==$"
                                << first.profit
                                << " 2nd==$"
                                << second.profit
                                << ")"
                                << endl
                                ;

                        if( second.profit > first.profit )
                        {
                            // keep the more profitable of existing two
                            if( VERBOSE == 2 )
                                cout 
                                    << "\t\tShifting more profitable 2nd *candidate* down to 1st" 
                                    << endl
                                    ;

                            first = second;
                        }

                        second = current;

                        if( VERBOSE == 2 )
                            dumpTransaction( second, "\t\tFound new 2nd *candidate* transaction: ");

                    }
                    else
                    {
                        if( VERBOSE == 2 )
                            cout 
                                << "\t\tFound less or equally profitable transaction ("
                                << "new==$"
                                << current.profit
                                << " vs "
                                << " 1st==$"
                                << first.profit
                                << " 2nd==$"
                                << second.profit
                                << ")"
                                << endl
                                ;

                    }


                }
            }

            //
            // reset the current transaction
            //
            current = RESET;
        }

        // processed dangling transaction, drop out
        if( day == days )
            break;

        //            
        // update current transaction tracker
        //

        if( current.buyIndex == -1 )
        {
            // starting a new transcation
            current.buyIndex = day;
            current.buyPrice = price;
        }
        else
        {
            // extending the current transaction
            current.sellIndex = day;
            current.sellPrice = price;

            current.profit = current.sellPrice - current.buyPrice;
        }

        if( VERBOSE == 2 )
            dumpTransaction( current, "\t\tCurrent Transaction: ");

        lastPrice = price;
    }

    maxProfit = 0;
    
    if (first.profit > 0)
    {
        if( VERBOSE )
            dumpTransaction( first, "\t1st Transaction: ");

        maxProfit += first.profit;

        if (second.profit > 0)
        {
            if( VERBOSE )
                dumpTransaction( second, "\t2nd Transaction: ");
    
            maxProfit += second.profit;
        }
    
    }
    else
        if( VERBOSE )
            cout << "\tNo profitable transactions found" << endl;

    return maxProfit;
}

void dumpTransaction( const transaction& tx, const char* prefix )
{
    if( prefix && *prefix )
    {
        cout << prefix;
    }

    // NOTE we used 1-based day# (buy/sellIndex)
    // to match the challenge overview

    cout 
        << "Buy"
        << " @" << (tx.buyIndex >= 0 ? tx.buyIndex+1 : tx.buyIndex)
        << " $" << tx.buyPrice
        << " Sell"
        << " @" << (tx.sellIndex >= 0 ? tx.sellIndex+1 : tx.sellIndex)
        << " $" << tx.sellPrice
        << " Profit="
        << tx.profit
        << endl
        ;

}

string elapsedTime( double elapsedNanos )
{
    string strElapsedTime = "";

    /*
    const int NANOS_PER_SECOND = 10^9;
    double nanosPart = fmod( elapsedNanos, NANOS_PER_SECOND );

    if( nanosPart )
        strElapsedTime = std::to_string( nanosPart ) + "ns";
    
    if( elapsedNanos >= NANOS_PER_SECOND )
    {
        elapsedNanos /= NANOS_PER_SECOND;

        double secsPart = fmod( elapsedNanos, 60 );


    }
        */

    strElapsedTime = to_string( elapsedNanos ) + "ns";

    return strElapsedTime;
}


//////////////////////////////////////////////////////////////
//
// Tests
//

/// @brief runs all tests returned by GetTestCases()
/// @return 0 on success, !0 on failure
int TestMain()
{
    vector<TestDefinition> testCases = GetTestCases();

    int SUITE_REPEATS = (TEST_REPETITION > 1 && !REPEAT_BY_TEST) ? TEST_REPETITION : 1;
    int TEST_REPEATS = (TEST_REPETITION > 1 && REPEAT_BY_TEST) ? TEST_REPETITION : 1;

    int testResult = 0;
    for( int s = 0; s < SUITE_REPEATS; s++ )
        for( int i = 0; i < testCases.size(); i++ )
            for( int t = 0; t < TEST_REPEATS; t++ )
                testResult += RunTest( testCases.at(i));

    if( perfTracker.size() > 0 )                
    {
        cout << endl;
        cout << "Performance Summary" << endl;
        cout << "-------------------" << endl;
        cout << "(avg time per test for " << TEST_REPETITION << " runs)" << endl;
        
        map<string,Profile>::iterator it;
        for( it = perfTracker.begin(); it != perfTracker.end(); it++ )
        {
            double ave = it->second.elapsed / ( 1.0f * it->second.runs );
            cout << it->first << " " << elapsedTime(ave) << endl;
        }

        cout << "====================" << endl;
    }
    return testResult;        
}

/// @brief runs an individual test case
/// @param testCase the test to be run
/// @return 0 on success, !0 on failure
int RunTest( TestDefinition testCase )
{
    cout << "Test: " << testCase.name;

    int actualResult = INVOKE_SUBMISSION( testCase );

    bool failed = actualResult != testCase.expectedResult;

    if( failed )
        cout << " Failure:";
    else
        cout << " Success:";

    cout << " maxProfit == " << actualResult;

    if( failed )
        cout << " vs expected == " << testCase.expectedResult;

    cout << endl;        

    return failed ? -1 : 0;
}

/// @brief gathers up the test cases to be run- see -t parameter
/// @return the test cases to be run
vector<TestDefinition> GetTestCases()
{
    if( JUDGE_TESTS.size() > 0 )
    {
        return JUDGE_TESTS;
    }

    vector<TestDefinition> allTestCases = {};

    {
        vector<TestDefinition> testCases = GetExampleTestCases();
        for( int i = 0; i < testCases.size(); i++ )
            allTestCases.push_back( testCases.at(i) );
    }

    {
        vector<TestDefinition> testCases = GetEdgeTestCases();
        for( int i = 0; i < testCases.size(); i++ )
            allTestCases.push_back( testCases.at(i) );
    }

    {
        vector<TestDefinition> testCases = GetMaxTestCases();
        for( int i = 0; i < testCases.size(); i++ )
            allTestCases.push_back( testCases.at(i) );
    }

    return allTestCases;
}

/// @brief defines various "edge" test cases
/// @return the edge test cases
vector<TestDefinition> GetEdgeTestCases()
{
    vector<TestDefinition> edgeTestCases = {};

    {
        string testName = "Empty";
        std::vector<int> inputs = {};
        int expected = 0;

        edgeTestCases.push_back( { testName, expected, inputs });

    }

    {
        string testName = "AllZeroes";
        std::vector<int> inputs = { 0, 0, 0, 0, 0 };
        int expected = 0;

        edgeTestCases.push_back( { testName, expected, inputs });
    }

    {
        string testName = "AllSameLow";
        std::vector<int> inputs = { 1, 1, 1, 1, 1 };
        int expected = 0;

        edgeTestCases.push_back( { testName, expected, inputs });
    }

    {
        string testName = "AllSameHigh";
        std::vector<int> inputs = { MAX_PRICE, MAX_PRICE, MAX_PRICE, MAX_PRICE, MAX_PRICE };
        int expected = 0;

        edgeTestCases.push_back( { testName, expected, inputs });
    }

    {
        string testName = "HiNo";
        std::vector<int> inputs = { 1, 4, 0, 0 };
        int expected = 3;

        edgeTestCases.push_back( { testName, expected, inputs });
    }

    {
        string testName = "NoHi";
        std::vector<int> inputs = { 0, 0, 0, 4 };
        int expected = 4;

        edgeTestCases.push_back( { testName, expected, inputs });
    }

    {
        string testName = "HiLoHi";
        std::vector<int> inputs = { 1, 4, 0, 2, 1, 5 };
        int expected = 7;

        edgeTestCases.push_back( { testName, expected, inputs });
    }

    {
        string testName = "NoHiNo";
        std::vector<int> inputs = { 0, 0, 0, 4, 0, 0 };
        int expected = 4;

        edgeTestCases.push_back( { testName, expected, inputs });
    }

    {
        string testName = "HiLoHiLo";
        std::vector<int> inputs = { 1, 4, 0, 2, 1, 5, 0, 2 };
        int expected = 7;

        edgeTestCases.push_back( { testName, expected, inputs });
    }

    {
        string testName = "LoHiLoHi";
        std::vector<int> inputs = { 0, 2, 1, 5, 0, 2, 1, 4  };
        int expected = 7;

        edgeTestCases.push_back( { testName, expected, inputs });
    }

    {
        string testName = "HiLoHiLoHi";
        std::vector<int> inputs = { 1, 4, 0, 2, 1, 5, 0, 2, 1, 5 };
        int expected = 8;

        edgeTestCases.push_back( { testName, expected, inputs });
    }

    {
        string testName = "LoHiLoHiLo";
        std::vector<int> inputs = { 0, 2, 1, 5, 0, 2, 1, 4, 0, 2  };
        int expected = 7;

        edgeTestCases.push_back( { testName, expected, inputs });
    }

    return edgeTestCases;
}

/// @brief defines various max (w/r/t # of inputs & price) test cases
/// @return max test cases
vector<TestDefinition> GetMaxTestCases()
{
    vector<TestDefinition> maxTestCases = {};

    {
        //
        // each day the price increases to last day price == MAX_PRICE
        //
        string testName = "MaxAllProfit";
        int expectedResult = MAX_PRICE;

        if( !EMIT_MAX_TEST_DATA )
            cout << testName << ": building input...";

        // NOTE we *must* preallocate- 
        // if we attempted to push_back each individual element,
        // we crash with a realloc eerror
        std::vector<int> maxInput = std::vector<int>(MAX_INPUTS);

        if( !EMIT_MAX_TEST_DATA )
            cout << "x" << maxInput.size() << "...";

        for( int i = 0; i < MAX_INPUTS; i++)
        {
            // each input is larger than the last;
            // we skip from 0 to 2 at the start so we end with MAX_PRICE
            maxInput[i] = i > 0 ? i + 1 : 0;
        }

        if( !EMIT_MAX_TEST_DATA )
            cout << "done." << endl;

        maxTestCases.push_back( { testName, expectedResult, maxInput } );
    }

    {
        //
        // maximally exercises the algorithm, with max transaction count 
        // single-day transacations, and constantly increasing profit
        //

        string testName = "MaxSeeSaw";

        if( !EMIT_MAX_TEST_DATA )
            cout << testName << ": building input...";

        std::vector<int> maxInput = std::vector<int>(MAX_INPUTS);

        if( !EMIT_MAX_TEST_DATA )
           cout << "x" << maxInput.size() << "...";

        for( int i = 0; i < MAX_INPUTS; i++)
        {
            maxInput[i] = i % 2 ? i + 1 : 0;
        }

        if( !EMIT_MAX_TEST_DATA )
            cout << "done." << endl;

        //
        // the last two transactions have the largest profits:
        // [    0] = 0
        // [    1] = 2
        // [    2] = 0
        // [    3] = 4
        // ....
        // [99996] = 0
        // [99997] = 99998
        // [99998] = 0
        // [99999] = 100000
        //
        int expectedResult = MAX_PRICE + (MAX_PRICE - 2);

        maxTestCases.push_back( { testName, expectedResult, maxInput } );
    }

    {
        //
        // steadily descreasing price, no profit
        //
        
        string testName = "MaxLoss";

        if( !EMIT_MAX_TEST_DATA )
            cout << testName << ": building input...";

        std::vector<int> maxInput = std::vector<int>(MAX_INPUTS);

        if( !EMIT_MAX_TEST_DATA )
            cout << "x" << maxInput.size() << "...";

        for( int i = 0; i < MAX_INPUTS; i++)
        {
            maxInput[i] = max( MAX_PRICE - i, 0 );
        }

        if( !EMIT_MAX_TEST_DATA )
            cout << "done." << endl;

        int expectedResult = 0;

        maxTestCases.push_back( { testName, expectedResult, maxInput } );
    }

    if( EMIT_MAX_TEST_DATA )
    {
        for( int t = 0; t < maxTestCases.size(); t++ )
        {
            if( t )
                cout << endl;

            TestDefinition maxTestDef = maxTestCases.at(t);
            cout << "// " << maxTestDef.name << endl;
            cout << "// expectedResult: " << maxTestDef.expectedResult << endl;

            cout << "{ ";

            for( int i = 0; i < maxTestDef.inputs.size(); i++ )
            {
                if( i )
                    cout << ", ";

                if( i && !(i % 100)) // newline every 100 inputs                   
                    cout << endl;

                cout << maxTestDef.inputs.at(i);
            }

            cout << " }" << endl;

        }
    }

    return maxTestCases;
}