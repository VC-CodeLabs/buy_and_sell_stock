//
// J A K U B
//
// you can add your test cases to the JUDGE_TESTS var below;
// if filled in, these will automatically be used instead of the built-in test cases;
// by default, each JUDGE_TESTS result (maxProfit) is validated, 
// and each test is run ten times, with avg time for each reported after all tests are completed.
// 
// once you've declared your JUDGE_TESTS,
// you can use the following command-line flags 
// to further refine behavior:
// -r# repeat tests # times, report avg time per test
// -t- disable test mode (no validation)
// -p- disable profiling (timed execution)
// -j- ignore JUDGE_TEST, revert to built-in tests
//

#include "BuyAndSellStock.h"

vector<TestDefinition> JUDGE_TESTS = 
{
    /*
    {
        "test1Name",
        2, // expectedResult
        { 1, 2, 3 } // price per day inputs
    },
    {
        "test2Name",
        MAX_PRICE, // expectedResult
        { 0, MAX_PRICE } // price per day inputs
    }
    */
    // add as many tests as needed;
    // see the EXAMPLE_TEST_CASES definition below
};

// global flags controlled by cmdline args
int VERBOSE = 0;
bool DO_PROFILING = false; // time each run of the algorithm
bool RUN_TESTS = false; // enabled w/ -t, else only examples are run w/ no programmatic validation
bool EMIT_MAX_TEST_DATA = false;
int TEST_REPETITION = 1;
bool REPEAT_BY_TEST = true; // given { A, B, C } test suite + -r3, runs { A, A, A, B, B, B, C, C, C } else -R3 runs { A, B, C, A, B, C, A, B, C }
TimerResolution TIMER_REZ = TIMER_REZ_NANOS;
ClockType CLOCK_TYPE = CLOCK_TYPE_HIGH_REZ;
bool USE_BRUTE_FORCE = true;

/// @brief entry point for the program- execution starts here, the os invokes this after loading the .exe
/// @param argc # of command-line args; always at least 1
/// @param argv command-line args; argv[0] is always the fully qualified name of the .exe
/// @return 0 on success, non-zero on failure
int main( int argc, char** argv )
{

    if( JUDGE_TESTS.size() > 0 )
    {
        // change some defaults in judge mode
        DO_PROFILING = true;
        RUN_TESTS = true;
        TEST_REPETITION = 10;
        // can be overridden with the command line
    }

    if( argc > 1 )
    {
        bool showSyntax = false;

        for( int argn = 1; argn < argc; argn++ )
        {
            char* currArg = argv[argn];
            if( currArg[0] == '-' )
            {
                switch( tolower(currArg[1]))
                {
                    case 'v':
                        switch( currArg[2] )
                        {
                            case '-':
                            case '0':
                                VERBOSE = 0;
                                break;
                            case '\0':
                            case '1':
                                VERBOSE = 1;
                                break;
                            case '2':
                                VERBOSE = 2;
                                break;
                            default:
                                showSyntax = true;
                                break;                        
                        }
                        break;
                    case 't':
                        RUN_TESTS = currArg[2] != '-';
                        break;
                    case 'p':
                        DO_PROFILING = currArg[2] != '-';
                        if( DO_PROFILING )
                        {
                            for( int i = 2; i < strlen(currArg); i++ )
                            switch(currArg[i])
                            {
                                case 'm': 
                                    TIMER_REZ = TIMER_REZ_MILLIS;
                                    break;
                                case 'n':
                                    TIMER_REZ = TIMER_REZ_NANOS;
                                    break;
                                case 'h':
                                    CLOCK_TYPE = CLOCK_TYPE_HIGH_REZ;
                                    break;
                                case 'o':                            
                                    CLOCK_TYPE = CLOCK_TYPE_MONOTONIC;
                                    break;
                                case 'y':
                                    CLOCK_TYPE = CLOCK_TYPE_SYSTEM;
                                    break;
                                default:
                                    throw (string("Unknown -p modifier ") + currArg[2]).c_str();                                    
                            }
                        }
                        break;                        
                    case 'e':
                        EMIT_MAX_TEST_DATA = true;
                        GetMaxTestCases();
                        return 0;         
                    case 'j':
                        if( currArg[2] == '-')  
                            JUDGE_TESTS.clear();
                        break;
                    case 'r':
                        if( currArg[2] )
                        {
                            if( currArg[2] == '-')
                                TEST_REPETITION = 1;
                            else if( isdigit( currArg[2] ))    
                                TEST_REPETITION = atoi(&currArg[2]);
                            else
                            {
                                cout << "Unsupported -" 
                                        << currArg[1] 
                                        << " modifier: " 
                                        << &currArg[2] 
                                        << endl;
                                
                                showSyntax = true;
                                break;
                            }
                        }
                        REPEAT_BY_TEST = !(currArg[1] == 'R');
                        break;
                    default:
                        cout << "Unsupported argument: " << currArg << endl;
                    case 'h':
                    case '?':
                        showSyntax = true;
                        break;
                }
            }
            else
                showSyntax = true;

            if( showSyntax )
                break;
        }

        if( showSyntax )
        {
            cout 
                << endl
                << "Usage: "
                << "\t"
                << argv[0] // the name of the exe
                << " [-v[#|0|-]] [-t[-]] [-p[m|n|-]] [-[r|R][#|-]] [-j-] [-e] [-?|-h]"
                << endl
                << "Where" << endl
                << "\t-v# sets verbose level:" << endl
                << "\t\t0: none/minimal" << endl
                << "\t\t1: summary" << endl
                << "\t\t2: working detail" << endl
                << "\t-v- is equivalent to -v0" << endl
                << "\t-v is equivalent to -v1" <<endl
                << endl
                << "\t-t run all tests w/ result validation" << endl
                << "\t\tif not specified," << endl
                << "\t\tonly the examples are run w/ no validation" << endl
                << "\t\t(but algorithm results are written to console)" << endl
                << "\t-t- switch off test mode" << endl
                << endl
                << "\t-p enable profiling (time each invocation of the algorithm)" << endl
                << "\t\tuse with -r#/-R# to compute average time across multiple runs;" << endl
                << "\t\t-pm use millisecond-scale profiling" << endl
                << "\t\t-pn use nanosecond-scale profiling" << endl
                << "\t-p- switch off profiling" << endl
                << endl
                << "\t-r#|-R# repeat tests # times" << endl
                << "\t\timplies -p to compute average time per test run;" << endl
                << "\t\timplies -t to run all tests and validate results;" << endl
                << "\t\t-r# repeats N runs of each test back-to-back" << endl
                << "\t\t\tgiven {A, B} tests, -r2 would run {A, A, B, B}" << endl
                << "\t\t-R# repeats the test suite N times" << endl
                << "\t\t\tgiven {A, B} tests, -R2 would run {A, B, A, B}" << endl
                << "\t-r- switch off test repetition (run each test once);" << endl
                << "\t\t# == 0 or 1 also resets to running tests once;" << endl
                << "\t-r and -R are mutually exclusive- last one wins;" << endl
                << "\t\tNOTE this is the only case-sensitive parameter!" << endl
                << endl
                << "\t-j- ignore JUDGE_TESTS for this run" << endl
                << endl
                << "\t-e emit Max* test data to console" << endl
                << "\t\tif spec'd, only the test data is generated," << endl
                << "\t\tno tests are run, all other params ignored" << endl
                << endl
                << "\t-h or -? shows command-line syntax" << endl
                << endl
                ;
            
            return 0;
        }
    }

    if( TEST_REPETITION > 1 )
    {
        if( !DO_PROFILING )
            DO_PROFILING = true;

        if( !RUN_TESTS)
            RUN_TESTS = true;
    }

    int result = 0;

    if( RUN_TESTS )
    {
        // automatically uses JUDGE_TESTS if !empty
        result = TestMain();
    }
    else        
    {
        result = SimpleMain();
    }

    if( RUN_TESTS )
    if( result == 0 )
    {
        cout << "All tests succeeded." << endl;
    }
    else
    {
        cout << abs(result) << " tests failed." << endl;
    }
    
    return result;
}

vector<TestDefinition> EXAMPLE_TEST_CASES = 
{
    {
        "Example1",
        6,
        {3,3,5,0,0,3,1,4}
    },
    {
        "Example2",
        4,
        {1,2,3,4,5}
    },
    {
        "Example3",
        0,
        {7,6,4,3,1}        
    }
}; // end of EXAMPLE_TEST_CASES

#define GetExampleTestCases() EXAMPLE_TEST_CASES

int SimpleMain()
{

    vector<TestDefinition> examples = JUDGE_TESTS.size() > 0 ? JUDGE_TESTS : GetExampleTestCases();

    for( int i = 0; i < examples.size(); i++ )
    {
        TestDefinition example = examples.at(i);

        cout << example.name << ": " << INVOKE_SUBMISSION(example) << endl;
    }

    return 0; // no errors
}

////////////////////////////////////////////////////////////////////
//
// The Solution algorithm
//

/// @brief struct to track a given transaction- buy+sell index+price, total profit
struct transaction {
    int buyIndex = -1; // zero-based day# of when we bought
    int buyPrice = 0; // price on the day we bought
    int sellIndex = -1; // zero-based day# of when we sold
    int sellPrice = 0; // price on the day we sold
    int profit = -1; // total profit
};

struct Profile {
    int64_t elapsed;
    int runs;
    int64_t first;
    int64_t fastest = -1;
    int fastIdx = -1;
    int64_t slowest = -1;
    int slowIdx = -1;
};

map<string,Profile> perfTracker = {};

typedef chrono::high_resolution_clock PROFILER_CLOCK;
// typedef chrono::system_clock PROFILER_CLOCK;
// typedef chrono::steady_clock PROFILER_CLOCK;

int TimedSubmission( TestDefinition& testDef )
{
    // cout << typeid(PROFILER_CLOCK).name() << endl;

    PROFILER_CLOCK::time_point begin = PROFILER_CLOCK::now();

    int maxProfit = SUBMISSION_ALGORITHM(testDef.inputs);

    // std::this_thread::sleep_for(std::chrono::milliseconds(15000));

    PROFILER_CLOCK::time_point end = PROFILER_CLOCK::now();

    // cout << "begin: " << format("%S", begin);

    // var type =  ?  : 

    int64_t elapsed;
    
    if( TIMER_REZ_MILLIS == TIMER_REZ)
        elapsed = std::chrono::duration_cast<std::chrono::milliseconds> (end - begin).count();
    else 
        elapsed = std::chrono::duration_cast<std::chrono::nanoseconds> (end - begin).count();

    cout << " Elapsed Time: " << elapsedTime(elapsed, TIMER_REZ) << " ";

    if( TEST_REPETITION > 1 )
    {
        map<string,Profile>::iterator it = perfTracker.find(testDef.name);
        if( it == perfTracker.end())
        {
            Profile profile = { elapsed, 1, elapsed };
            pair<map<string,Profile>::iterator, bool> inserted = perfTracker.insert( make_pair( testDef.name, profile ));
            it = inserted.first;
        }
        else
        {
            it->second.elapsed += elapsed;
            it->second.runs++;
        }    

        // if( elapsed )
        {
            if( it->second.fastest == -1 || it->second.fastest > elapsed )
            {
                it->second.fastest = elapsed;
                it->second.fastIdx = it->second.runs;
            }
            
            if( it->second.slowest == -1 || it->second.slowest < elapsed )
            {
                it->second.slowest = elapsed;
                it->second.slowIdx = it->second.runs;
            }
        }
    }

    return maxProfit;
}

void dumpTransaction( const transaction& tx, const char* prefix );

#if USE_ARRAY
int _Submission( int prices[], int days )
#else
int BrokenSubmission( vector<int>& prices )
#endif
{
    cout << " Broken ";

    #if !USE_ARRAY
    int days = prices.size();
    #endif

    if( VERBOSE )
        cout << endl;

    int maxProfit = -1;

    // ARRAY_LENGTH(prices); // prices is really an int*, so we can't derive the length

    if( VERBOSE )
    {
        cout << "\t" << "Input: {";
        for( int i = 0; i < min(days, 10); i++ )
        {
            if( i )
                cout << ",";

            if( i < 5 || days <= 10 )                
            {
                cout << " " << prices.at(i);
            }
            else
            {
                if( i == 5 )
                    cout << " ... ";

                cout << " " << prices.at( days - 10 + i);
            }

        }

        cout << " }";

        cout << " " << "# of Days: " << days << endl;
    }

    // TODO compute maxProfit

    const transaction RESET;
    transaction first, second, current;
    
    int lastPrice = -1;

    //
    // NOTE we do an extra step to process the last dangling transaction
    //
    for( int day = 0; day <= days; day++ )
    {
        int price = day < days ? prices.at(day) : -1;

        if( price < lastPrice )
        {
            //
            // price dropped, sell for profit *if any*
            //

            if( VERBOSE == 2 )
            if( day < days )
                cout 
                    << "\t\tPrice dropped @"
                    << (day+1)
                    << " was "
                    << "$" << lastPrice
                    << " now "
                    << "$" << price
                    << " checking for profit..."
                    << endl
                    ;
            else
                cout
                    << "\t\tProcessing dangling *candidate* transaction..."
                    << endl
                    ;

            current.profit = current.sellPrice - current.buyPrice;

            if( current.profit > 0 )
            {
                //
                // we have a profitable transaction
                //
                if( first.profit < 0 )
                {
                    first = current;

                    if( VERBOSE == 2 )
                        dumpTransaction( first, "\t\tFound 1st *candidate* transaction: " );
                }
                else if( second.profit < 0 )
                {
                    second = current;

                    if( VERBOSE == 2 )
                        dumpTransaction( second, "\t\tFound 2nd *candidate* transaction: " );
                }
                else
                {
                    if( current.profit > first.profit || current.profit > second.profit )
                    {
                        if( VERBOSE == 2 )
                            cout 
                                << "\t\tFound more profitable transaction ("
                                << "new==$"
                                << current.profit
                                << " vs "
                                << " 1st==$"
                                << first.profit
                                << " 2nd==$"
                                << second.profit
                                << ")"
                                << endl
                                ;

                        if( second.profit > first.profit )
                        {
                            // keep the more profitable of existing two
                            if( VERBOSE == 2 )
                                cout 
                                    << "\t\tShifting more profitable 2nd *candidate* down to 1st" 
                                    << endl
                                    ;

                            first = second;
                        }

                        second = current;

                        if( VERBOSE == 2 )
                            dumpTransaction( second, "\t\tFound new 2nd *candidate* transaction: ");

                    }
                    else
                    {
                        if( VERBOSE == 2 )
                            cout 
                                << "\t\tFound less or equally profitable transaction ("
                                << "new==$"
                                << current.profit
                                << " vs "
                                << " 1st==$"
                                << first.profit
                                << " 2nd==$"
                                << second.profit
                                << ")"
                                << endl
                                ;

                    }


                }
            }

            //
            // reset the current transaction
            //
            current = RESET;
        }

        // processed dangling transaction, drop out
        if( day == days )
            break;

        //            
        // update current transaction tracker
        //

        if( current.buyIndex == -1 )
        {
            // starting a new transcation
            current.buyIndex = day;
            current.buyPrice = price;
        }
        else
        {
            // extending the current transaction
            current.sellIndex = day;
            current.sellPrice = price;

            current.profit = current.sellPrice - current.buyPrice;
        }

        if( VERBOSE == 2 )
            dumpTransaction( current, "\t\tCurrent Transaction: ");

        lastPrice = price;
    }

    maxProfit = 0;
    
    if (first.profit > 0)
    {
        if( VERBOSE )
            dumpTransaction( first, "\t1st Transaction: ");

        maxProfit += first.profit;

        if (second.profit > 0)
        {
            if( VERBOSE )
                dumpTransaction( second, "\t2nd Transaction: ");
    
            maxProfit += second.profit;
        }
    
    }
    else
        if( VERBOSE )
            cout << "\tNo profitable transactions found" << endl;

    return maxProfit;
}

struct TransactionPairs {
    transaction tx1;
    transaction tx2;
    int totalProfit;
};

int /* BruteForce */ Submission( vector<int> prices  )
{
    // cout << " BruteForce ";
    
    vector<transaction> transactions = vector<transaction>(combos(prices.size()));

    // cout << " combosX" << transactions.size() << " ";
    int ti = 0;

    for( int bi = 0, bt = prices.size() - 1; bi < bt; bi++ )
    {
        for( int si = bi + 1; si < prices.size(); si++ )
        {
            int buyPrice = prices.at(bi);
            int sellPrice = prices.at(si);

            if( sellPrice > buyPrice )
            {
                if( ti >= transactions.size()) cout << " !" << ti;
                transactions[ti++] = { bi, buyPrice, si, sellPrice, sellPrice - buyPrice };
            }
        }
    }

    // cout << "profitableX" << ti << " ";

    transactions.resize(ti);

    if( ti > 0 )
    {
        /*
        long tx = 0;

        for( int bi1 = 0, bt1 = prices.size() - 1; bi1 < bt1; bi1++ )
        {
            for( int si1 = bi1 + 1; si1 < prices.size(); si1++ )
            {
                for( int bi2 = si1 + 1, bt2 = prices.size() - 1; bi2 < bt2; bi2++ )
                {
                    for( int si2 = bi2 + 1; si2 < prices.size(); si2++ )
                    {
                        // cout << (tx+1) << ": " << bi1 << "," << si1 << " + " << bi2 << "," << si2 << endl;
                        tx++;
                    }
                }
        
            }
        }
        */

        // vector<TransactionPairs> txPairs = vector<TransactionPairs>(tx + transactions.size());

        TransactionPairs txPair;
        txPair.totalProfit = -1;

        int txi = 0;
        for( int i = 0; i < transactions.size(); i++ )
        {
            transaction tx1 = transactions.at(i);
            transaction tx2; tx2.profit = 0;
            // txPairs[txi++] = { tx1, tx2, tx1.profit };
            if( tx1.profit > txPair.totalProfit )
            {
                txPair.tx1 = tx1;
                txPair.tx2 = tx2;
                txPair.totalProfit = tx1.profit;
            }
        }

        for( int tx1i = 0, tx1t = transactions.size() - 1; tx1i < tx1t; tx1i++ )
        {
            for( int tx2i = tx1i + 1; tx2i < transactions.size(); tx2i++ )
            {
                transaction tx1 = transactions.at(tx1i);
                transaction tx2 = transactions.at(tx2i);

                if( tx2.buyIndex > tx1.sellIndex )
                {
                    // txPairs[txi++] = { tx1, tx2, tx1.profit + tx2.profit };

                    if( tx1.profit + tx2.profit > txPair.totalProfit )
                    {
                        txPair.tx1 = tx1;
                        txPair.tx2 = tx2;
                        txPair.totalProfit = tx1.profit + tx2.profit;
                    }
                }

            }
        }

        /*
        txPairs.resize(txi);

        std::sort(txPairs.begin(), txPairs.end(), []( TransactionPairs a, TransactionPairs b) {
            return a.totalProfit > b.totalProfit;
        });
        */

        /*
        for( int i = 0; i < txPairs.size(); i++ )
        {
            cout << i;
            dumpTransaction(txPairs.at(i).tx1, " tx1: ");
            cout << i;
            dumpTransaction(txPairs.at(i).tx2, " tx2: ");

            cout << i << " totalProfit: " << txPairs.at(i).totalProfit << endl;
        }
        */

        // return txPairs.at(0).totalProfit;

        return txPair.totalProfit;

        // cout << "total combos: " << tx << "+" << transactions.size() << endl;
            
        // 0, 1, 2, 3
        // 0, 1
        // 0, 1 + 2, 3
        // 0, 2
        // 0, 3
        // 1, 2
        // 1, 3
        // 2, 3

        // 0, 1, 2, 3, 4
        // 0, 1
        // 0, 1 + 2, 3
        // 0, 1 + 2, 4
        // 0, 2
        // 0, 2 + 3, 4
        // 0, 3
        // 0, 4
        // 1, 2
        // 1, 2 + 3, 4
        // 1, 3
        // 2, 3
        // 2, 4

        // 0, 1, 2, 3, 4, 5
        // 0, 1 + 2, 3
        // 0, 1 + 2, 4
        // 0, 1 + 2, 5
        // 0, 2 + 3, 4
        // 0, 2 + 3, 5
        // 0, 3 + 4, 5
        // 0, 4
        // 0, 5
        // 1, 2 + 3, 4
        // 1, 2 + 3, 5
        // 1, 3 + 4, 5
        // 1, 4
        // 1, 5
        // 2, 3 + 4, 5
        // 2, 4
        // 2, 5
        // 3, 4
        // 3, 5
        // 4, 5

        // 0, 1, 2, 3, 4, 5, 6, 7, 8, 9
    }

    return 0;
}

void dumpTransaction( const transaction& tx, const char* prefix )
{
    if( prefix && *prefix )
    {
        cout << prefix;
    }

    // NOTE we used 1-based day# (buy/sellIndex)
    // to match the challenge overview

    cout 
        << "Buy"
        << " @" << (tx.buyIndex >= 0 ? tx.buyIndex+1 : tx.buyIndex)
        << " $" << tx.buyPrice
        << " Sell"
        << " @" << (tx.sellIndex >= 0 ? tx.sellIndex+1 : tx.sellIndex)
        << " $" << tx.sellPrice
        << " Profit="
        << tx.profit
        << endl
        ;

}

string elapsedTime( int64_t elapsed, TimerResolution timerRez )
{
    string strElapsedTime = "";

    /*
    const int NANOS_PER_SECOND = 10^9;
    double nanosPart = fmod( elapsedNanos, NANOS_PER_SECOND );

    if( nanosPart )
        strElapsedTime = std::to_string( nanosPart ) + "ns";
    
    if( elapsedNanos >= NANOS_PER_SECOND )
    {
        elapsedNanos /= NANOS_PER_SECOND;

        double secsPart = fmod( elapsedNanos, 60 );


    }
        */

    strElapsedTime = to_string( elapsed ) + (TIMER_REZ_MILLIS == timerRez ? "ms" :"ns");

    return strElapsedTime;
}


//////////////////////////////////////////////////////////////
//
// Tests
//

/// @brief runs all tests returned by GetTestCases()
/// @return 0 on success, !0 on failure
int TestMain()
{
    vector<TestDefinition> testCases = GetTestCases();

    int SUITE_REPEATS = (TEST_REPETITION > 1 && !REPEAT_BY_TEST) ? TEST_REPETITION : 1;
    int TEST_REPEATS = (TEST_REPETITION > 1 && REPEAT_BY_TEST) ? TEST_REPETITION : 1;

    int testResult = 0;
    for( int s = 0; s < SUITE_REPEATS; s++ )
        for( int i = 0; i < testCases.size(); i++ )
            for( int t = 0; t < TEST_REPEATS; t++ )
                testResult += RunTest( testCases.at(i));

    if( perfTracker.size() > 0 )                
    {
        cout << endl;
        cout << "Performance Summary" << endl;
        cout << "-------------------" << endl;
        cout << "(time per test for " << TEST_REPETITION << " runs)" << endl;
        
        // emit perf results in the same order they were executed
        for( int i = 0; i < testCases.size(); i++ )
        {
            map<string,Profile>::iterator it = perfTracker.find(testCases.at(i).name);
            double ave = ( 1.0f * it->second.elapsed ) / ( 1.0f * it->second.runs );

            cout << it->first << " ave:" << elapsedTime(ave, TIMER_REZ);

            if( TEST_REPETITION > 1 )
            {
                cout << " first:" << elapsedTime( it->second.first, TIMER_REZ );

                if( TEST_REPETITION > 2 )
                {
                    int64_t filteredElapsed = it->second.elapsed - it->second.first;
                    int filteredRuns = it->second.runs - 1;

                    // cout << " slowIdx:" << it->second.slowIdx;
                    if( it->second.slowIdx == -1 )
                        cout << " slowest:??";
                    else if( it->second.slowIdx == 1 )
                        cout << " slowest:#1";
                    else 
                    {
                        filteredElapsed -= it->second.slowest;
                        filteredRuns--;
                        cout << " slowest:" << elapsedTime( it->second.slowest, TIMER_REZ );
                    }

                    // cout << " fastIdx:" << it->second.fastIdx;
                    if( it->second.fastIdx == -1 )
                        cout << " fastest:??";
                    else if( it->second.fastIdx == 1 )                        
                        cout << " fastest:#1";
                    else if( it->second.fastIdx == it->second.slowIdx )                        
                        cout << " fastest:slowest";
                    else
                    {   
                        filteredElapsed -= it->second.fastest;
                        filteredRuns--;
                        cout << " fastest:" << elapsedTime( it->second.fastest, TIMER_REZ );
                    }

                    if( TEST_REPETITION > 3 )                        
                    {
                        double aave = ( 1.0f * filteredElapsed ) / ( 1.0f * filteredRuns );
                        cout << " aave:" << elapsedTime( aave, TIMER_REZ );

                    }
                }
            }

            cout << endl;
        }

        cout << "====================" << endl;
    }
    return testResult;        
}

/// @brief runs an individual test case
/// @param testCase the test to be run
/// @return 0 on success, !0 on failure
int RunTest( TestDefinition testCase )
{
    cout << "Test: " << testCase.name;

    int actualResult = INVOKE_SUBMISSION( testCase );

    bool failed = actualResult != testCase.expectedResult;

    if( failed )
        cout << " Failure:";
    else
        cout << " Success:";

    cout << " maxProfit == " << actualResult;

    if( failed )
        cout << " vs expected == " << testCase.expectedResult;

    cout << endl;        

    return failed ? -1 : 0;
}

/// @brief gathers up the test cases to be run- see -t parameter
/// @return the test cases to be run
vector<TestDefinition> GetTestCases()
{
    if( JUDGE_TESTS.size() > 0 )
    {
        return JUDGE_TESTS;
    }

    vector<TestDefinition> allTestCases = {};

    {
        vector<TestDefinition> testCases = GetExampleTestCases();
        for( int i = 0; i < testCases.size(); i++ )
            allTestCases.push_back( testCases.at(i) );
    }

    {
        vector<TestDefinition> testCases = GetEdgeTestCases();
        for( int i = 0; i < testCases.size(); i++ )
            allTestCases.push_back( testCases.at(i) );
    }

    // temporarily disabled- 11th hour issue w/ original algo, replacement has problems w/ very large (by size) test cases
    {
        vector<TestDefinition> testCases = GetMaxTestCases(100);
        for( int i = 0; i < testCases.size(); i++ )
            allTestCases.push_back( testCases.at(i) );
    }

    return allTestCases;
}

/// @brief defines various "edge" test cases
/// @return the edge test cases
vector<TestDefinition> GetEdgeTestCases()
{
    vector<TestDefinition> edgeTestCases = {};

    {
        string testName = "Empty";
        std::vector<int> inputs = {};
        int expected = 0;

        edgeTestCases.push_back( { testName, expected, inputs });

    }

    {
        string testName = "AllZeroes";
        std::vector<int> inputs = { 0, 0, 0, 0, 0 };
        int expected = 0;

        edgeTestCases.push_back( { testName, expected, inputs });
    }

    {
        string testName = "AllSameLow";
        std::vector<int> inputs = { 1, 1, 1, 1, 1 };
        int expected = 0;

        edgeTestCases.push_back( { testName, expected, inputs });
    }

    {
        string testName = "AllSameHigh";
        std::vector<int> inputs = { MAX_PRICE, MAX_PRICE, MAX_PRICE, MAX_PRICE, MAX_PRICE };
        int expected = 0;

        edgeTestCases.push_back( { testName, expected, inputs });
    }

    {
        string testName = "HiNo";
        std::vector<int> inputs = { 1, 4, 0, 0 };
        int expected = 3;

        edgeTestCases.push_back( { testName, expected, inputs });
    }

    {
        string testName = "NoHi";
        std::vector<int> inputs = { 0, 0, 0, 4 };
        int expected = 4;

        edgeTestCases.push_back( { testName, expected, inputs });
    }

    {
        string testName = "HiLoHi";
        std::vector<int> inputs = { 1, 4, 0, 2, 1, 5 };
        int expected = 8;

        edgeTestCases.push_back( { testName, expected, inputs });
    }

    {
        string testName = "NoHiNo";
        std::vector<int> inputs = { 0, 0, 0, 4, 0, 0 };
        int expected = 4;

        edgeTestCases.push_back( { testName, expected, inputs });
    }

    {
        string testName = "HiLoHiLo";
        std::vector<int> inputs = { 1, 4, 0, 2, 1, 5, 0, 2 };
        int expected = 8;

        edgeTestCases.push_back( { testName, expected, inputs });
    }

    {
        string testName = "LoHiLoHi";
        std::vector<int> inputs = { 0, 2, 1, 5, 0, 2, 1, 4  };
        int expected = 9;

        edgeTestCases.push_back( { testName, expected, inputs });
    }

    {
        string testName = "HiLoHiLoHi";
        std::vector<int> inputs = { 1, 4, 0, 2, 1, 5, 0, 2, 1, 5 };
        int expected = 10;

        edgeTestCases.push_back( { testName, expected, inputs });
    }

    {
        string testName = "LoHiLoHiLo";
        std::vector<int> inputs = { 0, 2, 1, 5, 0, 2, 1, 4, 0, 2  };
        int expected = 9;

        edgeTestCases.push_back( { testName, expected, inputs });
    }

    return edgeTestCases;
}

/// @brief defines various max (w/r/t # of inputs & price) test cases
/// @return max test cases
vector<TestDefinition> GetMaxTestCases( int limit /* = MAX_INPUTS */)
{
    vector<TestDefinition> maxTestCases = {};

    const int max_inputs = limit;
    const int max_price = limit;
    {
        //
        // each day the price increases to last day price == max_price
        //
        string testName = "MaxAllProfit";
        int expectedResult = max_price;

        if( !EMIT_MAX_TEST_DATA )
            cout << testName << ": building input...";

        // NOTE we *must* preallocate- 
        // if we attempted to push_back each individual element,
        // we crash with a realloc eerror
        std::vector<int> maxInput = std::vector<int>(MAX_INPUTS);

        if( !EMIT_MAX_TEST_DATA )
            cout << "x" << maxInput.size() << "...";

        for( int i = 0; i < max_inputs; i++)
        {
            // each input is larger than the last;
            // we skip from 0 to 2 at the start so we end with max_price
            maxInput[i] = i > 0 ? i + 1 : 0;
        }

        if( !EMIT_MAX_TEST_DATA )
            cout << "done." << endl;

        maxTestCases.push_back( { testName, expectedResult, maxInput } );
    }

    {
        //
        // maximally exercises the algorithm, with max transaction count 
        // single-day transacations, and constantly increasing profit
        //

        string testName = "MaxSeeSaw";

        if( !EMIT_MAX_TEST_DATA )
            cout << testName << ": building input...";

        std::vector<int> maxInput = std::vector<int>(max_inputs);

        if( !EMIT_MAX_TEST_DATA )
           cout << "x" << maxInput.size() << "...";

        for( int i = 0; i < max_inputs; i++)
        {
            maxInput[i] = i % 2 ? i + 1 : 0;
        }

        if( !EMIT_MAX_TEST_DATA )
            cout << "done." << endl;

        //
        // the last two transactions have the largest profits:
        // [    0] = 0
        // [    1] = 2
        // [    2] = 0
        // [    3] = 4
        // ....
        // [99996] = 0
        // [99997] = 99998
        // [99998] = 0
        // [99999] = 100000
        //
        int expectedResult = max_price + (max_price - 2);

        maxTestCases.push_back( { testName, expectedResult, maxInput } );
    }

    {
        //
        // steadily descreasing price, no profit
        //
        
        string testName = "MaxLoss";

        if( !EMIT_MAX_TEST_DATA )
            cout << testName << ": building input...";

        std::vector<int> maxInput = std::vector<int>(max_inputs);

        if( !EMIT_MAX_TEST_DATA )
            cout << "x" << maxInput.size() << "...";

        for( int i = 0; i < max_inputs; i++)
        {
            maxInput[i] = max( max_price - i, 0 );
        }

        if( !EMIT_MAX_TEST_DATA )
            cout << "done." << endl;

        int expectedResult = 0;

        maxTestCases.push_back( { testName, expectedResult, maxInput } );
    }

    if( EMIT_MAX_TEST_DATA )
    {
        for( int t = 0; t < maxTestCases.size(); t++ )
        {
            if( t )
                cout << endl;

            TestDefinition maxTestDef = maxTestCases.at(t);
            cout << "// " << maxTestDef.name << endl;
            cout << "// expectedResult: " << maxTestDef.expectedResult << endl;

            cout << "{ ";

            for( int i = 0; i < maxTestDef.inputs.size(); i++ )
            {
                if( i )
                    cout << ", ";

                if( i && !(i % 100)) // newline every 100 inputs                   
                    cout << endl;

                cout << maxTestDef.inputs.at(i);
            }

            cout << " }" << endl;

        }
    }

    return maxTestCases;
}

long combos(const long n)
{
    long f = 0;
    for (int i=1; i<=n; ++i)
        f += i;
    return f;
}