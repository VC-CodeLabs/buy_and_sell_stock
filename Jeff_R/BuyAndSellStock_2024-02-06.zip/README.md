The solution can be found in the cpp in Submission method;
this uses a vector as input rather than an array (to support determining input length),
but the vector can be init'd just like an array:
vector<int> foo = { 1, 2, 3 };
see comments in the header for more on this topic.

The performance is generally sub-millisecond, even when using max inputs,
so the high-res timer and nanosecond intervals are used;
as can be seen in the test log, my Max* test cases 
all generally clock in at under 1ms (< 1m nanoseconds)

Numerous command-line parameters are supported, use -h or -? to get the details.

To evaluate the solution, update the JUDGE_TESTS 
near the top of the cpp with your test cases, 
recompile and re-run.